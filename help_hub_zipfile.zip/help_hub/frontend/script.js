const socket = io("http://localhost:5000");
const form = document.getElementById("helpForm");
const pendingDiv = document.getElementById("pendingRequests");
const acceptedDiv = document.getElementById("acceptedRequests");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = {
    name: e.target.name.value,
    phone: e.target.phone.value,
    address: e.target.address.value,
    category: e.target.category.value,
    description: e.target.description.value,
  };

  await fetch("http://localhost:5000/api/requests", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  form.reset();
  alert("Request submitted! Help is on the way.");
});

const renderRequests = (requests) => {
  pendingDiv.innerHTML = "";
  acceptedDiv.innerHTML = "";

  requests.forEach((req) => {
    const card = `
      <div class="request-card" data-tilt>
        <h3>${req.category} Help Needed</h3>
        <p><strong>${req.name}</strong> • ${req.phone}</p>
        <p>📍 ${req.address}</p>
        <p>📝 ${req.description}</p>
        ${req.volunteerName ? `<p>🚀 Accepted by: <strong>${req.volunteerName}</strong></p>` : ""}
        <div class="actions">
          ${req.status === "pending" ? `
            <button class="accept-btn" onclick="acceptRequest('${req._id}')">I'll Help!</button>
          ` : req.status === "accepted" ? `
            <button class="complete-btn" onclick="completeRequest('${req._id}')">Mark Complete</button>
          ` : ""}
        </div>
      </div>
    `;

    if (req.status === "pending") {
      pendingDiv.innerHTML += card;
    } else if (req.status === "accepted") {
      acceptedDiv.innerHTML += card;
    }
  });

  // Re-init tilt
  VanillaTilt.init(document.querySelectorAll("[data-tilt]"), {
    max: 15,
    speed: 400,
    glare: true,
    "max-glare": 0.5,
  });
};

socket.on("requestsUpdate", (requests) => {
  renderRequests(requests);
});

const acceptRequest = async (id) => {
  const name = prompt("Enter your name (volunteer):");
  if (!name) return;

  await fetch(`http://localhost:5000/api/requests/${id}/accept`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ volunteerName: name }),
  });
};

const completeRequest = async (id) => {
  if (confirm("Mark this request as completed?")) {
    await fetch(`http://localhost:5000/api/requests/${id}/complete`, {
      method: "PUT",
    });
    setTimeout(async () => {
      await fetch(`http://localhost:5000/api/requests/${id}`, { method: "DELETE" });
    }, 2000);
  }
};

// Initial load
fetch("http://localhost:5000/api/requests").then(r => r.json()).then(renderRequests);