import mongoose from "mongoose";

const requestSchema = new mongoose.Schema({
  name: { type: String, required: true },
  phone: { type: String, required: true },
  address: { type: String, required: true },
  category: { type: String, required: true },
  description: { type: String, required: true },
  status: { type: String, enum: ["pending", "accepted", "completed"], default: "pending" },
  volunteerName: { type: String, default: null },
}, { timestamps: true });

export default mongoose.model("Request", requestSchema);