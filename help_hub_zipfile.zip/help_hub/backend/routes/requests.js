import express from "express";
import Request from "../models/Request.js";

const router = express.Router();

// Get all requests
router.get("/", async (req, res) => {
  try {
    const requests = await Request.find().sort({ createdAt: -1 });
    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create new request
router.post("/", async (req, res) => {
  try {
    const request = new Request(req.body);
    await request.save();
    res.status(201).json(request);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Accept request
router.put("/:id/accept", async (req, res) => {
  try {
    const request = await Request.findByIdAndUpdate(
      req.params.id,
      { status: "accepted", volunteerName: req.body.volunteerName },
      { new: true }
    );
    res.json(request);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Complete request
router.put("/:id/complete", async (req, res) => {
  try {
    const request = await Request.findByIdAndUpdate(
      req.params.id,
      { status: "completed" },
      { new: true }
    );
    res.json(request);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete completed request
router.delete("/:id", async (req, res) => {
  try {
    await Request.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;