import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import dotenv from "dotenv";
import connectDB from "./config/db.js";
import requestRoutes from "./routes/requests.js";
import Request from "./models/Request.js";

dotenv.config();
connectDB();

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: "*" }
});

app.use(cors());
app.use(express.json());
app.use("/api/requests", requestRoutes);

// Real-time broadcast
const broadcastRequests = async () => {
  const requests = await Request.find().sort({ createdAt: -1 });
  io.emit("requestsUpdate", requests);
};

// Watch for any change in the Request collection
Request.watch().on("change", broadcastRequests);

io.on("connection", (socket) => {
  console.log("Client connected:", socket.id);
  socket.on("disconnect", () => console.log("Client disconnected"));
});

const PORT = process.env.PORT || 5000;
httpServer.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});